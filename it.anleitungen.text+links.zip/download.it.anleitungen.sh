#!/bin/bash

# install:
# - wget
# - wkhtmltopdf

### not working ###
## - pandoc
## - texlive
## - librsvg2-bin (rsvg-convert)



# download as html 
rm -Rf it.anleitungen
mkdir -p it.anleitungen
cd it.anleitungen
# link level is 5 by default;
#wget -r -np -k -p https://www.uni-mannheim.de/it/anleitungen
wget -r -np -p https://www.uni-mannheim.de/it/anleitungen

# convert to pdf
HTML_FILES=$(find -name *.html)
for HTML_FILE in $HTML_FILES
do
	#  wkhtmltopdf --enable-local-file-access www.uni-mannheim.de/it/anleitungen/wlan/index.html wlan.pdf
	# ./www.uni-mannheim.de/it/anleitungen/microsoft-exchange/weiterleitung-einrichten/index.html 
        PDF_PATH="pdf/"$(dirname $(echo $HTML_FILE | sed 's/^\.\///' | sed 's/\/index.html//'))
        mkdir -p $PDF_PATH
	PDF_FILE=$PDF_PATH"/"$(basename $(echo $HTML_FILE | sed 's/\/index.html//'))".pdf"
        echo $PDF_FILE
        wkhtmltopdf --enable-local-file-access $HTML_FILE $PDF_FILE

done



