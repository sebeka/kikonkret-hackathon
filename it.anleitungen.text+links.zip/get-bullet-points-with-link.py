#!/bin/python3

# install html2text (python3)

import os
import re
import sys
import html2text

htmlfiles = []

def list_files_recursive(path='.'):
    for entry in os.listdir(path):
        full_path = os.path.join(path, entry)
        if os.path.isdir(full_path):
            list_files_recursive(full_path)
        else:
            if os.path.basename(full_path) == "index.html":
                htmlfiles.append(full_path)
                create_txt_file(full_path)
    return htmlfiles


def create_txt_file(input_file='index.html'):
    with open(input_file, 'r') as file:
        file_content = file.read().replace( "\n", " ")

    # remove the header stuff
    if file_content.find("nav>") < 0:
        print("ERROR: Skipping " + input_file + ", no \"nav>\" found", file=sys.stderr)
        return
    file_content = re.sub(r".*nav>", "", file_content)

    # remove the footer stuff
    if file_content.find("</main>") < 0:
        print("ERROR: Skipping " + input_file + ", no \"</main>\" found", file=sys.stderr)
        return
    file_content = re.sub(r"</main>.*", "", file_content)

    #print(input_file)
    h = html2text.HTML2Text()
    h.ignore_links = False
    markup = h.handle(file_content)

    # repair relativ links
    markup = markup.replace("](/", "](https://www.uni-mannheim.de/")

    #print (markup)
    #print ("-----------------------------")
    #print(input_file)
    #print(file_content)

    txtfile = os.path.basename(input_file.replace("/index.html", "")) + ".txt"
    txtpath = "it.anleitungen/text" + os.path.dirname(input_file.replace("it.anleitungen", "").replace("/index.html", ""))
    print(txtpath + "/" + txtfile) 
    if not os.path.isdir(txtpath):
        os.makedirs(txtpath)
    f = open(txtpath + "/" + txtfile, "w")
    f.write(markup)
    f.close()



HTML_FILES = list_files_recursive('it.anleitungen/www.uni-mannheim.de/it/anleitungen/')
#print(HTML_FILES)
